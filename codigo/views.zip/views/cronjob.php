<?php
$mysqli = new mysqli("localhost", "ciudad5128", "-A1o2667", "sgec1");

$query = "INSERT INTO historial SELECT * FROM reservas WHERE DATE(reservas.fecha) < CURDATE()";
$mysqli->query($query);

$query = "DELETE FROM reservas WHERE DATE(fecha) < CURDATE()";
$mysqli->query($query);


/* close connection */
$mysqli->close();
?>