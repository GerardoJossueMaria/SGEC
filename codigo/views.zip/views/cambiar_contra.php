<?php

if (isset($_COOKIE['contrasena']) || isset($_SESSION['contra'])){
    if(isset($_SESSION["cambiado"])){
        header('Location:?c=principal');
    }else{

    }
        
}else{
    header('Location:?c=home');
    die() ;
}



?>
<html lang="es" style="    overflow-x: hidden;">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="libs/bootstrap-5.1.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/cssc/login&check.css">

    <title>Nueva contraseña</title>

<style>

        .footer{
            background-color: #212529; /* Black*/
            position:fixed;
            bottom:0px;
            left:0px;
            right:0px;
            padding:7px;
            text-align:center;
            z-index:4;
            color:white
        }

    #iniciar{
    font-family: "Roboto", sans-serif;
    text-transform: uppercase;
    outline: 0;
    background: #537efd;
    width: 100%;
    border: 0;
    padding: 15px;
    color: #FFFFFF;
    font-size: 14px;
    -webkit-transition: all 0.3 ease;
    transition: all 0.3 ease;
    cursor: pointer;
}



.form{
border-radius:3%;
    margin-top: -18%! important;
     margin-bottom: 30%! important;
}
.login-page{
border-radius:3%;
}
.nombres{
float:left; 
font-weight:bold;
}

.obligatorio{
float:left !important;
color:gray;
 text-align:justify;
 margin-bottom:10px;
 font-size:0.8rem;
}


@media only screen 
        and (min-device-width: 320px) 
        and (max-device-width: 812px)
         {



.obligatorio{
font-size:2rem;

}
.nombres{
font-size:40px;
margin-top:3%;
}

.navbar>div{
display: flex;
    align-items: center;
    justify-content: center;
    align-content: center;
}
.navbar h4{
text-align:center}
a img{
border-radius: 1px;
    margin-left: 5%;
    display: inline-block;
    width: 270px;
    height: 133px;
}


.footer{
font-size:25px}
.login-page {
    width: 80%;
    height: auto;
padding: 0%;
    margin-top: 200px;
    margin: auto;
}
.form {
    font-size: 12px;
    z-index: 1;
    background: #FFFFFF;
    /* max-width: 500px; */
    padding: 45px;
    text-align: center;
    box-shadow: 0 0 20px 0 rgb(0 0 0 / 20%), 0 5px 5px 0 rgb(0 0 0 / 24%);
    margin-bottom: 20%! important;

}

.h2, h2 {
    font-size: calc(3.325rem + .9vw);
}
.form input {
    font-family: "Roboto", sans-serif;
    outline: 0;
    background: #f2f2f2;
    width: 100%;
    border: 0;
    margin: 10px 0 55px !important;
    padding: 39px;
    box-sizing: border-box;
    font-size: 40px;
}
.custom-control-input{
    width: 10%;
    /* font-size: 100; */
    -ms-transform: scale(0.5);
    -moz-transform: scale(0.5);
    -webkit-transform: scale(0.5);
    -o-transform: scale(0.5);
    padding: 10px;
border-radius:50%
}
.custom-control{
    display: flex;
    justify-content: flex-start;
    align-items: center;
    align-content: flex-end;
margin:10px auto}
.custom-control-label {padding-top:50px !important}
#iniciar {
    font-family: "Roboto", sans-serif;
    text-transform: uppercase;
    outline: 0;
    background: #537efd;
    width: 100%;
    border: 0;
    padding: 30px;
    margin: 80px auto;
    margin-bottom:22px;
    color: #FFFFFF;
    font-size: 40px;
    -webkit-transition: all 0.3 ease;
    transition: all 0.3 ease;
    cursor: pointer;
}

a{
    font-size: 40px;
    margin-bottom: 30px;
}
.h4, h4 {
    font-size: calc(2.275rem + .3vw);
}
.login-page{
    padding: 0%;
    margin-top: 100px;
}
.form{
max-width:100% !important;
border-radius:3%;
margin-top: -21% !important;
}
.custom-control-label{    font-size: 40px;
    padding-left: 32px;
}
.login-page{
margin-top:200px !important;
border-radius:3%}
.form input{
margin: 70px 0 15px;
}
}


</style>

<script src="libs/js/validarCambiarContra.js">
    </script>

</head>

<body style="font-size:12px !important">
   <nav class="navbar navbar-expand-lg navbar-light" style="background: #212529;justify-content: left;">
        <div>
            <a href="https://www.educa2.madrid.org/web/centro.ies.ciudadescolar.madrid" target="_blank" class="navbar-brand" style="display:inline-block;">
                <img src="libs/img/logo_ciudadescolar.png" height="70" width="140" style="border-radius:1px; margin-left:5%;display:inline-block;" alt="CoolBrand">
            </a>
            <h4 style="color:rgba(255, 255, 255, 0.9); display:inline-block;"> Sistema de Gestión de Espacios Comunes</h4>
        </div>
    </nav>
    <div class="login-page">
        <div style="position: relative;text-align:center;">
            
        </div>
        <div class="form" style="padding-top:3%;">
        <h2>Nueva contraseña</h2>
        <hr class="my-4" style="background-color:gray;">
            
      
            <form style='font-size:14px' class="login-form" action="?c=cambio_contra" method="post" onsubmit="return validar();">
            
              
             <p class="nombres">  Nueva contraseña <span style="color:red">*</span></p>


             <p class="obligatorio">La contraseña debe incluir al menos 8 caracteres, una mayúscula, un número y un caracter especial (+,-,/ o *).</p>
             
               <input class="form-control" type="password" id="contra" name="contrasena1"  onkeydown="myFunction(this)" required >
             
             <p class="nombres">  Confirmar nueva contraseña <span style="color:red">*</span></p>
               <input class="form-control" type="password" value="" name="contrasena2"  id="contrasena2" onkeydown="myFunction(this)" required>
                
                <p class="obligatorio"> Los campos marcados con <span style="color:red"> *</span> son obligatorios</p><br>
                <button id="iniciar" >Confirmar</button>

            </form>
            <?php if(isset($_SESSION["error2"])){ ?>     
                 <?php echo $_SESSION["error2"];?>               
            <?php   unset($_SESSION["error2"]);
    
        }?>
        </div>
    </div>
<div class="footer">
       <p>© Copyright 2022 | Sistema de Gestión de Espacios Comunes | IES Ciudad Escolar</p>
</div>


</body>

</html>

