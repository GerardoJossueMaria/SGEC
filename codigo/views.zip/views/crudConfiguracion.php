<?php

if ((isset($_COOKIE['contrasena']) || isset($_SESSION['contra']) && isset($_SESSION["cambiado"])) ){

if($_SESSION["crudConfiguracion"]==0){

   header('Location:?c=principal');
    
  }
else{}
        
}else{
    header('Location:?c=home');
    die() ;
}



?>
<html lang="es" style="    overflow-x: hidden;">
<head>
  
    <title>Gestionar parámetros</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $(".alert").delay( 2200 ).fadeOut(1100);
  });
</script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="libs/bootstrap-5.1.3-dist/css/bootstrap.min.css">

</head>
<body style="font-size:12px !important">

<?php include "menu.php";


$count=$this->crud->crudConfiguracion(1);

if($count[0]==0){
    
    echo '
    <div class="row >
    <div class="col-md-12 ">
    <h1 class="display-3"> No se han creado configuraciones aún</h1>';
 
    echo "<a href='?c=crudConfiguracion&page=".$_GET['page']."&crear=1'><button name='crear' style='font-size:14px; margin-bottom:30px' class='btn btn-success'> Agregar</button></a>
  
    ";
    if(isset($_GET["crear"])){
        if(isset($_SESSION['vacio'])){
            echo $_SESSION['vacio'];
            unset($_SESSION['vacio']);
        }

        echo "<div style='    width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        align-content: center;'><form style='font-size:14px' action='?c=crearConfiguracion&pag=".$_GET['page']."' method='post' > <table class='table table-striped bg-white ' style='margin-top:2%'>";
        
                echo '<tr>';
                echo '<th> id</th>';
                echo '<th> Nombre</th>';
                echo '<th> Valor</th>';
                ;
               

                echo '</tr>';
                echo '<tr>';
                echo "<td><input type='number' name='dato[]' style='width:210px'></input></td>";
                echo "<td><input type='text' name='dato[]' style='width:220px'></input></td>";
                echo "<td><input type='number' min='0' name='dato[]' style='width:220px'></input></td>";
               
               

                echo '</tr>';

                echo "</table>";
                echo '<div class="alert alert-warning" role="alert">
                            Antes de crear una nueva configuración, consúltelo con el administrador de esta aplicación para confirmar si es posible implementarla
                        </div>';
        echo "<input class='btn btn-primary'  type='submit'  name='agregar-ult' value='Crear'>  </input>";
        echo "<input  class='btn btn-danger'type='submit' style='font-size:14px' name='cancelar' value='Cancelar'></input>";

        echo "</form></div>";




    }

    echo '</div>
    </div>
    </div>';
    
    
}
else{

$iteams_pagina=6;

$total_pages=ceil($count[0]/$iteams_pagina);

$page=0;

if(isset($_GET["page"]) && !empty($_GET["page"])){
    $page=$_GET["page"];
}else{
    $page=1;
}

$offset=($page-1) * $iteams_pagina;

$result=$this->crud->crudConfiguracion(2,$iteams_pagina,$offset);

$_SESSION['cuantas']=count($result[0]);



?>

<script>

$(document).ready(function(){
$("#myModal").modal();
});
</script>


<div class="row" style="margin-top:5%">

                <div class="col-md-12 ">
                <h1 style="color:black; text-align:center; margin-bottom:0%; background-color:white; margin-top:50px" >Configuración</h1>
                    
                    
                    <?php
                    /*AGREGAR AQUI EL FORMULARIO PARA CREAR */
                    
                  
                    if(isset($_SESSION['error2'])){
                        echo $_SESSION['error2'];
                        unset($_SESSION['error2']);
                    }
                    else if(isset($_SESSION['exito'])){
                        echo $_SESSION['exito'];
                        unset($_SESSION['exito']);
                    }

                    if(isset($_GET["crear"])){
                        if(isset($_SESSION['vacio'])){
                            echo $_SESSION['vacio'];
                            unset($_SESSION['vacio']);
                        }

                        echo  
        '<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h3 class="modal-title" id="exampleModalLongTitle">Crear configuración</h3>
                </div>
                <div class="modal-body">';
        
                echo "<form style='font-size:14px' action='?c=crearConfiguracion&pag=".$_GET['page']."' method='post'>";
               
                                        
                                
                echo '<div class="form-group">';
                    echo "<input class='form-control' type='hidden'  name='dato[]' value=' ' required</input>";
                    echo '</div>';
                
                    echo '<div class="form-group">
                    <label for="">Nombre</label>';
                    echo "<input class='form-control' type='text'  name='dato[]' value='' required></input>";
                    echo '</div>';
                                    
                                                
                                          
                    echo '<div class="form-group">
                    <label for="">Valor</label>';
                    echo "<input class='form-control' type='number' min='0'  name='dato[]' value='' required></input>";
                    echo '</div>';
                  
                    echo '<div class="modal-footer">';
                    echo '<div class="alert-warning p-3 text-center" >
                    <i class="bi bi-exclamation-circle" style="font-size:50px;display:block"></i>
                    <br>
                            Antes de crear una nueva configuración, consúltelo con el administrador de esta aplicación para confirmar si es posible implementarla
                        </div>';
                    echo "<input class='btn btn-primary' type='submit'  name='agregar-ult' value='Crear'></input> ";
                    echo '<a href="?c=crudConfiguracion&page='.$_GET['page'].'"><button type="button" style="font-size:14px" class="btn btn-danger">Cancelar</button></a>';
                    echo '</div>';
                    echo "</form>";
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                    }


                    
                    if(isset($_SESSION["modificar"])){

                            $id=$_SESSION["modificar"];
                    
                            $resu=$this->crud->modifConfiguracion($id);

                            echo  
                        '<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h3 class="modal-title" id="exampleModalLongTitle">Modificar configuración</h3>
                                </div>
                                <div class="modal-body">';
                        
                            echo "<form style='font-size:14px' action='?c=modificarConfiguracion&pag=".$_GET['page']."' method='post'>";
                            if(isset($_SESSION['vacio'])){
                                echo $_SESSION['vacio'];
                                unset($_SESSION['vacio']);
                            }
                                                    
                            foreach($resu as $nombre_columna){
                            for($i=0;$i<count($nombre_columna)/2;$i++){
                                if($i==0){
                                echo '<div class="form-group">';
                                    echo "<input class='form-control' type='hidden' readonly name='dato[]' value='".$nombre_columna[$i]."' required></input>";
                                    echo '</div>';
                                }
                                elseif($i==1){
                                    echo '<div class="form-group">
                                    <label for="">Nombre</label>';
                                    echo "<input class='form-control' type='text'  name='dato[]' value='".$nombre_columna[$i]."' required></input>";
                                    echo '</div>';

                                    
                            }

                                elseif($i==2){
                                    echo '<div class="form-group">
                                    <label for="">Valor</label>';
                                    echo "<input class='form-control' type='number' min='0'  name='dato[]' value='".$nombre_columna[$i]."' required></input>";
                                    echo '</div>';
                                    }

                                

                                
                                
                                

                                
                                    
                            }
                            }
                            
                            echo '<div class="modal-footer">';
                            echo "<input class='btn btn-primary' type='submit' style='font-size:14px'  name='modificar-ult' value='Actualizar'></input> ";
                            echo '<button type="button" class="btn btn-danger cancelar" style="font-size:14px" data-dismiss="modal">Cancelar</button>';                                                    echo '</div>';
                            echo '</div>';
                            echo "</form>";
                            echo '</div>';
                            echo '</div>';
                            echo '</div>';
                            echo '</div>';
                                                    
                     
                                                
                                                
                            
                        };
                        
                        
                        
                    ?>
       
<?php

       echo '<div class="container" style="margin-top:60px;">



       <div class="row">
           
                       <div class="col-md-12 ">';
        echo "<a href='?c=crudConfiguracion&page=".$_GET['page']."&crear=1'><button name='crear' style='font-size:14px;margin-bottom:30px'  class='btn btn-success'> Agregar</button></a>  ";
       
       echo  '<div class="table-responsive-sm">
       <table class="table table-striped bg-white table-hover" style="text-align: center; margin-top:1%">';



        foreach($result[1] as $indice){
            if($indice=="id"){

            }else{
                echo "<th>".$indice."</th>";
            }
        }
        

        echo "<th>Acción</th>";
        echo "</tr>";
        ?>
<form style='font-size:14px' action="?c=borrarConfiguracion&pag=<?php echo $_GET["page"]?>" method="post"> 

<?php
        
        foreach($result[0] as $indice=>$dato){

            foreach($dato as $x=>$y){
        
            
                if($x=="id"){
                            
                }else{
                    echo "<td>".$y."</td>";
                }
                
                
                //$vivienda=new Vivienda($y);
                //$i=new Vivienda($dato["id"],$dato["tipo"],$dato["zona"],$dato["direccion"],$dato["ndormitorios"],$dato["tamano"],$dato["precio"]);           
            }
      
            ?>

            <td><button  title="Modificar" class="btn btn-primary" name="modificar" value="<?php echo $dato["id"] ?>"> <i class="bi bi-pencil-square"></i></button></td>


            <?php
            echo "</tr>";
        
            }
        
       // echo "</table>";
  
  ?>
           </table>
        </div>
        </div>
        
        <script>
                $(document).ready(function(){
                    $('.dltBtn').click(function(e){
                        e.preventDefault();
                        var id = $(this).attr('data-id');
                        var page = $(this).attr('data-page');
                        Swal.fire({
                            title: '¿Desea eliminar este registro?',
                            text: "Esta acción es irreversible",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#dc3545',
                            cancelButtonColor: 'gray',
                            confirmButtonText: 'Eliminar',
                            cancelButtonText: 'Cancelar'

                            }).then((result) => {
                                if (result.isConfirmed) {
                                    window.location.href = "?c=borrarConfiguracion&id="+id+"&pag="+page;
 
                                }
                        })
                    });
                });
            </script>


  
 </form>



 <?php
 
 //--------------------------------------------------------------------

echo "<br>";

//listado

?>
<div style="margin-bottom: 100px;
    display: flex;
    justify-content: center">
<nav aria-label="...">
		<ul class="pagination">
		<li style="<?php echo $_GET['page']==1 ? 'display:none' : '' ?>" class="page-item">
				<a class="page-link" href="?c=crudConfiguracion&page=<?php echo $_GET['page']-1?>"><</a>
			</li>
            <li class="page-item" style="<?php echo $_GET['page']==1 || $_GET['page']==2 ? 'display:none' : '' ?>">
                    <a class="page-link" href="?c=crudConfiguracion&page=1">1 </a>
                </li>
            <li style="<?php echo $_GET['page']==1|| $_GET['page']==2 || $_GET['page']==3 ? 'display:none' : '' ?>">
				    <a class="page-link" href="">...</a>
			    </li>
				<!--con un bucle mostramos todas las páginas que hay-->
				<?php for($i=1;$i<=$total_pages;$i++){
                   if($i==$_GET["page"]-1){
                    echo '<li class="page-item" >
                    <a class="page-link" href="?c=crudConfiguracion&page='.$i.'">'.$i.' </a>
                    </li>';
                   }
                   elseif($i==$_GET["page"]){

                    echo '<li class="page-item active" >
                    <a class="page-link" href="?c=crudConfiguracion&page='.$_GET["page"].'">'.$_GET["page"].' </a>
                    </li>';
                    ?>
                  
				<?php }elseif($i==$_GET["page"]+1){
                    echo '<li class="page-item" >
                    <a class="page-link" href="?c=crudConfiguracion&page='.$i.'">'.$i.' </a>
                    </li>';
                    
                }
                
            }
                ?>
                <li style="<?php echo $_GET['page']==$total_pages-1 || $_GET['page']==$total_pages|| $_GET['page']==$total_pages-2  ? 'display:none' : '' ?>">
				    <a class="page-link" href="">...</a>
			    </li>
                <li class="page-item" style="<?php echo $_GET['page']==$total_pages ||$_GET['page']==$total_pages-1  ? 'display:none' : '' ?>">
                    <a class="page-link" href="?c=crudConfiguracion&page=<?php echo $total_pages?>"><?php echo $total_pages?> </a>
                </li>
				<!--Para ir a la página siguiente en el enlace ponemos que le lleve a la página actual +1-->
                <li style="<?php echo $_GET['page']==$total_pages ? 'display:none' : '' ?>">
				<a class="page-link" href="?c=crudConfiguracion&page=<?php echo $_GET['page']+1?>">></a>
			</li>				
		</ul>
    </nav>
</div>
<?php } ?>
<script>
$(".cancelar").click(function(){

<?php 
    if(isset($_SESSION["modificar"])){
        unset($_SESSION["modificar"]);
    }

    ?>
    
});


</script>
</body>
</html>