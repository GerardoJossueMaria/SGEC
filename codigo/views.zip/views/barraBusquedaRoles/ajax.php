<?php
session_start();

//Including Database configuration file.

//Database connection.

$con = MySQLi_connect(

   "localhost", //Server host name.

   "ciudad5128", //Database username.

   "-A1o2667", //Database password.

   "sgec1" //Database name or anything you would like to call it.

);

mysqli_query($con, "SET CHARACTER SET 'utf8'");
mysqli_query($con, "SET SESSION collation_connection ='utf8_unicode_ci'");

//Check connection

if (MySQLi_connect_errno()) {

   echo "Failed to connect to MySQL: " . MySQLi_connect_error();

}
//Getting value of "search" variable from "script.js".

if (isset($_POST['search'])) {

//Search box value assigning to $Name variable.

   $Name = $_POST['search'];
   $page = $_POST['page'];
  
//Search query.

   $Query = "SELECT * FROM roles WHERE id LIKE '%$Name%' OR nombre LIKE '%$Name%' ORDER BY id LIMIT 10 ";

//Query execution

   $ExecQuery = MySQLi_query($con, $Query);

//Creating unordered list to display result.

   echo '
   <form style="font-size:14px" action="?c=borrarRoles&pag='.$page.'" method="post"> 
   <ul class="list-group">

   ';

   //Fetching result from database.

   while ($Result = MySQLi_fetch_array($ExecQuery)) {

       ?>

   <!-- Creating unordered list items.

        Calling javascript function named as "fill" found in "script.js" file.

        By passing fetched result as parameter. -->

   
   <!-- Assigning searched result in "Search box" in "search.php" file. -->
   <li class="list-group-item busqueda" style="font-size: 15px;"  >
       <?php echo $Result['nombre']; ?>
       <a class="dltBtn btn btn-danger float-right ml-2"   data-id="<?php echo $Result["id"]; ?>" data-page="<?php echo $page; ?>" href="javascript:void(0)"><i class="bi bi-trash"></i></a>
       <button  title="Modificar" class="btn btn-primary float-right" name="modificar" value="<?php echo $Result["id"] ?>"> <i class="bi bi-pencil-square"></i></button>

       </li></a>

   <!-- Below php code is just for closing parenthesis. Don't be confused. -->

   <?php

}}


?>

</ul> 
 <script>

                $(document).ready(function(){
                    $('.dltBtn').click(function(e){
                        e.preventDefault();
                        var id = $(this).attr('data-id');
                        var page = $(this).attr('data-page');
                        Swal.fire({
                            title: '¿Desea eliminar este registro?',
                            text: "Esta acción es irreversible",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#dc3545',
                            cancelButtonColor: 'gray',
                            confirmButtonText: 'Eliminar',
                            cancelButtonText: 'Cancelar'

                            }).then((result) => {
                                if (result.isConfirmed) {
                                    window.location.href = "?c=borrarRoles&id="+id+"&pag="+page;
 
                                }
                        })
                    });
                });
            </script>