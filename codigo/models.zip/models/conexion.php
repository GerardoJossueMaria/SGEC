<?php

class Conexiones{

    public function conexion(){
        try{
            $conexion=new PDO("mysql:host=localhost;dbname=sgec1;charset=utf8","ciudad5128","-A1o2667");
            $conexion->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            return $conexion;
        }
        catch(PDOException $e){
            echo $e->getMessage();
            return null;
   
        }
    }

}

?>